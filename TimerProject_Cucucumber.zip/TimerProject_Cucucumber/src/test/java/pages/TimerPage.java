package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import java.util.NoSuchElementException;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


public class TimerPage<String> {

    public TimerPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    @FindBy(how = How.NAME, using = "start_a_timer")
    public WebElement txtstart_a_timer;

    @FindBy(how = How.XPATH, using = "//input[@alt='GO!']")
    public WebElement btnGO;

    @FindBy(how = How.ID, using = "progressText")
    public WebElement welProgressText;

    public void Timer(String time)
    {
    	txtstart_a_timer.sendKeys(time);
  
        
    }

    public void ClickGo()
    {
    	btnGO.submit();
    }
    
    public String GetText() {
    	welProgressText.getText();
    }
    
    public void verifyTimer() {
    	FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
		wait.pollingEvery(1,  TimeUnit.SECONDS);
		wait.withTimeout(25, TimeUnit.SECONDS);

		Function<WebDriver, Boolean> function = new Function<WebDriver, Boolean>()
				{
					public Boolean apply(WebDriver arg0) {
						String txt=arg0.findElement(By.id("progressText")).getText();
						System.out.println("Remaining time is " + txt);
						if(txt.equals("Time Expired!"))
						{
							
							return true;
							
						}
						return false;
					}
				};

		wait.until(function);
		driver.switchTo().alert();
		driver.switchTo().alert().accept();
    }

}
