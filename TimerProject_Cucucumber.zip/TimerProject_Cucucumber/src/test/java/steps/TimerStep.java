package steps;

import Base.BaseUtil;
import com.aventstack.extentreports.GherkinKeyword;


import org.junit.Assert;
import org.openqa.selenium.By;
import pages.TimerPage;

import java.util.List;
import java.util.Map;


public class TimerStep extends BaseUtil{

    private  BaseUtil base;

    public TimerStep(BaseUtil base) {
        this.base = base;
    }


    @Given("^I navigate to the Timer page$")
    public void iNavigateToTheTimerPage() throws Throwable {


        base.scenarioDef.createNode(new GherkinKeyword("Given"), "I navigate to the Timer page");
        System.out.println("Navigate Timer Page");
        base.Driver.navigate().to("http://e.ggtimer.com/");
    }


    @And("^I enter ([^\"]*)$")
    public void iEnterUsernameAndPassword(String userName, String password) throws Throwable {
        base.scenarioDef.createNode(new GherkinKeyword("And"), "I enter time");
        System.out.println("Timer is : " + time);
       
    }
    
    @And("^I click go button$")
    public void iClickLoginButton() throws Throwable {
        base.scenarioDef.createNode(new GherkinKeyword("And"), "I click go button");
        TimerPage page = new TimerPage(base.Driver);
        page.ClickGo();
    }

    @Then("^I should see the timer page$")
    public void iShouldSeeTheUserformPage() throws Throwable {
        scenarioDef.createNode(new GherkinKeyword("Then"), "I should see the timer page");

        Assert.assertEquals("Its not displayed", base.Driver.findElement(By.id("ProcessText")).isDisplayed(), true);
        TimerPage page=new TimerPage(base.Driver);
        page.verifyTimer();
    }

   
  
}
